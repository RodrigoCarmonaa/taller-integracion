<?php  
    //conexion con nuestra bd
    $conexion= mysqli_connect("localhost", "root", "", "login_register_db");
    
    
    /* para comprobar si se hizo la conexion exitosamente con nuestra bd
    if ($conexion){
        echo 'conectado exitosamente a la base de datos';

    }else{
        echo 'No se ha podido conectar a la base de datos ';
    }


    */
     

?>